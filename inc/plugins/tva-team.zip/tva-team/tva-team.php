<?php
/**
 * Plugin Name: TVA Team
 * Plugin URI: http://themes.tienvooracht.nl/
 * Description: Enables a custom team post type.
 * Version: 1.0.1
 * Author: Tienvooracht
 * Author URI: http://www.tienvooracht.nl
 *
 * This is based on the WordPress community-curated standards for common post types, taxonomies, and metadata.
 * @see https://github.com/justintadlock/content-type-standards
 */


// Exit when cheating!
if( ! defined( 'ABSPATH' ) ) exit;


// Plugin Class
if ( ! class_exists( 'TVA_Team_Post_Type' ) ) :

class TVA_Team_Post_Type {

	/**
	 * The constructor method for the TVA_Team_Post_Type class.
	 *
	 * @since 1.0.0
	 */

	public function __construct() {

		// Plugin activation
		register_activation_hook( __FILE__, array( &$this, 'plugin_activation' ) );

		// Textdomain
		load_plugin_textdomain( 'tva', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

		// Init
		add_action( 'init', array( &$this, 'tva_create_team_custom_post_type' ) );
		//add_action( 'init', array( &$this, 'tva_build_team_taxonomies_category' ) );	

	}


	/**
	 * Flush rewrite rule
	 *
	 * @since 1.0.0
	 */

	function plugin_activation() {

		$this->tva_create_team_custom_post_type();

		flush_rewrite_rules();

	}


	/**
	 * Registers team post type & categories
	 *
	 * @since 1.0.0
	 */

	function tva_create_team_custom_post_type() {

		// Rewrite
		$rewrite = array(

			'slug'			=> 'team-members',
			'with_front'	=> false,
			'pages'			=> true,
			'feeds'			=> true,
			'ep_mask'		=> EP_PERMALINK,

		); 

		//Suport
		$supports = array(

			'title',
			'editor',
			'author',
			'thumbnail',
			//'excerpt',
			//'category',
			//'custom-fields',
			//'comments'

		);

		// Labels
		$labels = array(

			'name'               => __( 'Team Members', 'tva' ),
			'singular_name'      => __( 'Team Member', 'tva' ),
			'menu_name'          => __( 'Team Members', 'tva' ),
			'name_admin_bar'     => __( 'Team Member', 'tva' ),
			'add_new'            => __( 'Add New', 'tva' ),
			'add_new_item'       => __( 'Add New Team Member', 'tva' ),
			'edit_item'          => __( 'Edit Team Member', 'tva' ),
			'new_item'           => __( 'New Team Member', 'tva' ),
			'view_item'          => __( 'View Team Member', 'tva' ),
			'search_items'       => __( 'Search Team Member', 'tva' ),
			'not_found'          => __( 'No team member found', 'tva' ),
			'not_found_in_trash' => __( 'No team member found in trash', 'tva' ),
			'all_items'          => __( 'Team Members', 'tva' ),

		);

		// Args
		$args = array(

			'description'			=> '',
			'public'				=> true,
			'publicly_queryable'	=> true,
			'show_in_nav_menus'		=> true,
			'show_in_admin_bar'		=> true,
			'exclude_from_search'	=> false,
			'show_ui'				=> true,
			'show_in_menu'			=> true,
			'menu_position'			=> null,
			'menu_icon'				=> 'dashicons-groups',
			'can_export'			=> true,
			'delete_with_user'		=> false,
			'hierarchical'			=> false,
			'has_archive'			=> 'team',
			'query_var'				=> 'team',
			//'capability_type'     	=> 'portfolio_project',
			'map_meta_cap'      	=> true,
			'rewrite'				=> $rewrite,
			'supports'				=> $supports,
			'labels'				=> $labels

		);

		register_post_type( __( 'team' ), $args );

	}


	function tva_build_team_taxonomies_category() {

		// Capabilities
		$capabilities = array(
	
			'manage_terms' => 'manage_team',
			'edit_terms'   => 'manage_team',
			'delete_terms' => 'manage_team',
			'assign_terms' => 'edit_team'

		);

		// Rewrite
		$rewrite = array(

			'slug'			=> 'team/category',
			'with_front'	=> false,
			'hierarchical'	=> true,
			'ep_mask'		=> EP_NONE

		);

		// Labels
		$labels = array(

			'name'                       => __( 'Team Categories', 'tva' ),
			'singular_name'              => __( 'Team Category', 'tva' ),
			'menu_name'                  => __( 'Categories', 'tva' ),
			'name_admin_bar'             => __( 'Category', 'tva' ),
			'search_items'               => __( 'Search Categories', 'tva' ),
			'popular_items'              => __( 'Popular Categories', 'tva' ),
			'all_items'                  => __( 'All Categories', 'tva' ),
			'edit_item'                  => __( 'Edit Category', 'tva' ),
			'view_item'                  => __( 'View Category', 'tva' ),
			'update_item'                => __( 'Update Category', 'tva' ),
			'add_new_item'               => __( 'Add New Category', 'tva' ),
			'new_item_name'              => __( 'New Category Name', 'tva' ),
			'parent_item'                => __( 'Parent Category', 'tva' ),
			'parent_item_colon'          => __( 'Parent Category:', 'tva' ),
			'separate_items_with_commas' => null,
			'add_or_remove_items'        => null,
			'choose_from_most_used'      => null,
			'not_found'                  => null,

		);

		// Args
		$args = array(

			'public'			=> true,
			'show_ui'			=> true,
			'show_in_nav_menus'	=> true,
			'show_tagcloud'		=> true,
			'show_admin_column'	=> true,
			'hierarchical'		=> true,
			'query_var'			=> 'team_category',
			//'capabilities'		=> $capabilities,
			'rewrite'			=> $rewrite,
			'labels'			=> $labels,

		);

		register_taxonomy( 'team_category', 'team', $args );

	}

}

new TVA_Team_Post_Type;

endif;