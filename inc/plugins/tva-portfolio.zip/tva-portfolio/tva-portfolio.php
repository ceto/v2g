<?php
/**
 * Plugin Name: TVA Portfolio
 * Plugin URI: http://themes.tienvooracht.nl/
 * Description: Enables a custom portfolio post type.
 * Version: 1.0.1
 * Author: Tienvooracht
 * Author URI: http://www.tienvooracht.nl
 *
 * This is based on the WordPress community-curated standards for common post types, taxonomies, and metadata.
 * @see https://github.com/justintadlock/content-type-standards
 */


// Exit when cheating!
if( ! defined( 'ABSPATH' ) ) exit;


// Plugin Class
if ( ! class_exists( 'TVA_Portfolio_Post_Type' ) ) :

class TVA_Portfolio_Post_Type {

	/**
	 * The constructor method for the TVA_Portfolio_Post_Type class.
	 *
	 * @since 1.0.0
	 */

	public function __construct() {

		// Plugin activation
		register_activation_hook( __FILE__, array( &$this, 'plugin_activation' ) );

		// Textdomain
		load_plugin_textdomain( 'tva', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

		// Init
		add_action( 'init', array( &$this, 'tva_create_portfolio_custom_post_type' ) );
		add_action( 'init', array( &$this, 'tva_build_portfolio_taxonomies_category' ) );
		add_action( 'init', array( &$this, 'tva_build_portfolio_taxonomies_tag' ) );

	}


	/**
	 * Plugin Activation
	 *
	 * @since 1.0.0
	 */

	function plugin_activation() {

		$this->tva_create_portfolio_custom_post_type();

		flush_rewrite_rules();

	}


	/**
	 * Registers portfolio_project post type, categories & tags
	 *
	 * @since 1.0.0
	 */

	function tva_create_portfolio_custom_post_type() {

		// Rewrite
		$rewrite = array(

			'slug'			=> 'portfolio',
			'with_front'	=> false,
			'pages'			=> true,
			'feeds'			=> true,
			'ep_mask'		=> EP_PERMALINK,

		); 

		//Suport
		$supports = array(

			'title',
			'editor',
			'author',
			'thumbnail',
			//'excerpt',
			//'category',
			//'custom-fields',
			//'comments'

		);

		// Labels
		$labels = array(

			'name'					=> __( 'Portfolio items', 'tva-theme-tools' ),
			'singular_name'			=> __( 'Portfolio', 'tva-theme-tools' ),
			'menu_name'				=> __( 'Portfolio', 'tva-theme-tools' ),
			'name_admin_bar'		=> __( 'Portfolio Project', 'tva-theme-tools' ),
			'add_new'				=> __( 'Add New', 'tva-theme-tools' ),
			'add_new_item'			=> __( 'Add New Project', 'tva-theme-tools' ),
			'edit_item'				=> __( 'Edit Project', 'tva-theme-tools' ),
			'new_item'				=> __( 'New Project', 'tva-theme-tools' ),
			'view_item'				=> __( 'View Project', 'tva-theme-tools' ),
			'search_items'			=> __( 'Search Projects', 'tva-theme-tools' ),
			'not_found'				=> __( 'No projects found', 'tva-theme-tools' ),
			'not_found_in_trash'	=> __( 'No projects found in trash', 'tva-theme-tools' ),
			'all_items'				=> __( 'Projects', 'tva-theme-tools' ),

		);

		// Args
		$args = array(

			'description'			=> '',
			'public'				=> true,
			'publicly_queryable'	=> true,
			'show_in_nav_menus'		=> true,
			'show_in_admin_bar'		=> true,
			'exclude_from_search'	=> false,
			'show_ui'				=> true,
			'show_in_menu'			=> true,
			'menu_position'			=> 20,
			'menu_icon'				=> 'dashicons-portfolio',
			'can_export'			=> true,
			'delete_with_user'		=> false,
			'hierarchical'			=> false,
			'has_archive'			=> 'portfolio',
			'query_var'				=> 'portfolio_project',
			//'capability_type'     	=> 'portfolio_project',
			'map_meta_cap'      	=> true,
			'rewrite'				=> $rewrite,
			'supports'				=> $supports,
			'labels'				=> $labels

		);

		register_post_type( __( 'portfolio_project' ), $args );

	}


	function tva_build_portfolio_taxonomies_category() {

		// Capabilities
		$capabilities = array(
	
			'manage_terms' => 'manage_portfolio_project',
			'edit_terms'   => 'manage_portfolio_project',
			'delete_terms' => 'manage_portfolio_project',
			'assign_terms' => 'edit_portfolio_project'

		);

		// Rewrite
		$rewrite = array(

			'slug'			=> 'portfolio_category',
			'with_front'	=> false,
			'hierarchical'	=> true,
			'ep_mask'		=> EP_NONE

		);

		// Labels
		$labels = array(

			'name'                       => __( 'Project Categories', 'tva' ),
			'singular_name'              => __( 'Project Category', 'tva' ),
			'menu_name'                  => __( 'Categories', 'tva' ),
			'name_admin_bar'             => __( 'Category', 'tva' ),
			'search_items'               => __( 'Search Categories', 'tva' ),
			'popular_items'              => __( 'Popular Categories', 'tva' ),
			'all_items'                  => __( 'All Categories', 'tva' ),
			'edit_item'                  => __( 'Edit Category', 'tva' ),
			'view_item'                  => __( 'View Category', 'tva' ),
			'update_item'                => __( 'Update Category', 'tva' ),
			'add_new_item'               => __( 'Add New Category', 'tva' ),
			'new_item_name'              => __( 'New Category Name', 'tva' ),
			'parent_item'                => __( 'Parent Category', 'tva' ),
			'parent_item_colon'          => __( 'Parent Category:', 'tva' ),
			'separate_items_with_commas' => null,
			'add_or_remove_items'        => null,
			'choose_from_most_used'      => null,
			'not_found'                  => null,

		);

		// Args
		$args = array(

			'public'			=> true,
			'show_ui'			=> true,
			'show_in_nav_menus'	=> true,
			'show_tagcloud'		=> true,
			'show_admin_column'	=> true,
			'hierarchical'		=> true,
			'query_var'			=> 'portfolio_category',
			//'capabilities'		=> $capabilities,
			'rewrite'			=> $rewrite,
			'labels'			=> $labels,

		);

		register_taxonomy( 'portfolio_category', 'portfolio_project', $args );

	}


	function tva_build_portfolio_taxonomies_tag() {

		// Capabilities
		$capabilities = array(
	
			'manage_terms' => 'manage_portfolio_project',
			'edit_terms'   => 'manage_portfolio_project',
			'delete_terms' => 'manage_portfolio_project',
			'assign_terms' => 'edit_portfolio_project'

		);

		// Rewrite
		$rewrite = array(

			'slug'			=> 'portfolio_tag',
			'with_front'	=> false,
			'hierarchical'	=> false,
			'ep_mask'		=> EP_NONE

		);

		// Labels
		$labels = array(

			'name'                       => __( 'Project Tags', 'tva' ),
			'singular_name'              => __( 'Project Tag', 'tva' ),
			'menu_name'                  => __( 'Tags', 'tva' ),
			'name_admin_bar'             => __( 'Tag', 'tva' ),
			'search_items'               => __( 'Search Tags', 'tva' ),
			'popular_items'              => __( 'Popular Tags', 'tva' ),
			'all_items'                  => __( 'All Tags', 'tva' ),
			'edit_item'                  => __( 'Edit Tag', 'tva' ),
			'view_item'                  => __( 'View Tag', 'tva' ),
			'update_item'                => __( 'Update Tag', 'tva' ),
			'add_new_item'               => __( 'Add New Tag', 'tva' ),
			'new_item_name'              => __( 'New Tag Name', 'tva' ),
			'separate_items_with_commas' => __( 'Separate tags with commas', 'tva' ),
			'add_or_remove_items'        => __( 'Add or remove tags', 'tva' ),
			'choose_from_most_used'      => __( 'Choose from the most used tags', 'tva' ),
			'not_found'                  => __( 'No tags found', 'tva' ),
			'parent_item'                => null,
			'parent_item_colon'          => null,

		);

		// Args
		$args = array(

			'public'			=> true,
			'show_ui'			=> true,
			'show_in_nav_menus'	=> true,
			'show_tagcloud'		=> true,
			'show_admin_column'	=> true,
			'hierarchical'		=> false,
			'query_var'			=> 'portfolio_tag',
			//'capabilities'		=> $capabilities,
			'rewrite'			=> $rewrite,
			'labels'			=> $labels,

		);

		register_taxonomy( 'portfolio_tag', 'portfolio_project', $args );

	}


}

new TVA_Portfolio_Post_Type;

endif;